<!DOCTYPE html>

<html>
    <head>
        <title>Wichtige Benachrichtigung</title>
    </head>

    <body>
        <h1>Ihr Termin</h1>
        <p>Es wurde ein Termin für Sie vereinbart.</p>
        <p>Mit freundlichen Grüßen</p>
        <p>Dr. Richard Zauner<br>
           +43/123 123 123 123<br>
           ordination@example.com</p>
    </body>
</html>
